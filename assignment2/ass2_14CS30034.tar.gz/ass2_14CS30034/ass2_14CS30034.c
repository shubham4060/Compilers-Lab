#include "myl.h"

/* *********************** function for printing character array ********************************************************* */

int prints(char *arr)
   {
      int i=0,j;
      for(i=0;arr[i]!='\0';i++);
      i;
      __asm__ __volatile__ ("syscall"::"a"(1), "D"(1), "S"(arr), "d"(i));
      return(i);
   }

/* ********************************* function for printing integer ****************************************** */

int printi(int n)
  {
     char buff[20],var;
     int i=0,temp;
     if(n==0)
         {
              __asm__ __volatile__ ("syscall"::"a"(1), "D"(1), "S"("0"), "d"(1)); 
              return(1);
         }
     if(n<0)
         {
                 n=-n;
                 buff[0]='-';
                 i=1;
         }
     while(n!=0)
          {
               temp=n%10;
               buff[i++]=(char)('0'+temp);
               n/=10;
          }
     int k=0;
     if(buff[0]=='-')
       {k=1;
       while(k<(i/2)+1)
          {   
              
              var=buff[k];  
              buff[k]=buff[i-k];
              buff[i-k]=var;
              k++;
          }
          
       }
     else
     {
     while(k<(i/2))
          {   
              
              var=buff[k];  
              buff[k]=buff[i-k-1];
              buff[i-k-1]=var;
              k++;
          }
      }
     __asm__ __volatile__ ("syscall"::"a"(1), "D"(1), "S"(buff), "d"(i));
     return(i);
  }

/* ******************************************* function for reading integer ******************************************************** */

int readi(int *ep)
{     
      char buff[20];
      __asm__ __volatile__ ("syscall"::"a"(0), "D"(0), "S"(buff), "d"(20));
      int i=0;
      int sum=0;
      if(buff[0]=='-')
       {
           for(i=1;buff[i]!='\n';i++)
             {    
                   if(buff[i]<48||buff[i]>57)
                           {
                                  *ep=1;
                                  return -1;
                           }

             }
      *ep=0;
      for(i=1;buff[i]!='\n';i++)
          sum=(10*sum)+(int)(buff[i]-'0'); 
      sum=-sum;
       }
      else
      {
      for(i=0;buff[i]!='\n';i++)
             {    
                   if(buff[i]<48||buff[i]>57)
                           {
                                  *ep=1;
                                  return -1;
                           }

             }
      *ep=0;
      for(i=0;buff[i]!='\n';i++)
          sum=(10*sum)+(int)(buff[i]-'0');   
      }
 
      return sum;
}   

/* ********************************* function to read float values ***************************************************** */

int readf(float *fp)
  {
      char buff[20];
      int i=0,index=-1,size;
      int dec=0;
      float frac=0;
      __asm__ __volatile__ ("syscall"::"a"(0), "D"(0), "S"(buff), "d"(20));
      if(buff[0]=='-')
      {
              for(i=1;buff[i]!='\n';i++)
               {
                    if(buff[i]=='.')
                         {
                           index=i;
                         }
               }
          size=i;
          for(i=1;buff[i]!='\n';i++)
              {
                    if(i==index)
                        continue;
                    if(buff[i]<48||buff[i]>57)
                           {
                                  *fp=-1;
                                  return 1;
                           }
              }
          if(index==-1)
               { 
                  for(i=1;buff[i]!='\n';i++)
                     dec=(10*dec)+(int)(buff[i]-'0');
                  *fp=-dec;
               }
           else
               {
                        for(i=1;i<index;i++)
                            dec=(10*dec)+(int)(buff[i]-'0');
                        for(i=size-1;i>index;i--)
                            frac=(frac/10.0)+(float)((buff[i]-'0')/10.0);
                        *fp=-1*(dec+frac);
                }
          return 0;
      }
      else
      {
          for(i=0;buff[i]!='\n';i++)
               {
                    if(buff[i]=='.')
                         {
                           index=i;
                         }
               }
          size=i;
          for(i=0;buff[i]!='\n';i++)
              {
                    if(i==index)
                        continue;
                    if(buff[i]<48||buff[i]>57)
                           {
                                  *fp=-1;
                                  return 1;
                           }
              }
          if(index==-1)
               { 
                  for(i=0;buff[i]!='\n';i++)
                     dec=(10*dec)+(int)(buff[i]-'0');
                  *fp=dec;
               }
           else
               {
                        for(i=0;i<index;i++)
                            dec=(10*dec)+(int)(buff[i]-'0');
                        for(i=size-1;i>index;i--)
                            frac=(frac/10.0)+(float)((buff[i]-'0')/10.0);
                        *fp=(dec+frac);
                }
          return 0;
      }
  }

/* *************************** function for printing float values *************************************************************** */

int printd(float f)
     {
           char buff[20];
           int count=0,i=0;
           if(f==0)
                {
                       buff[0]='0';
                       buff[1]='.';
                       int x=6;
                       while(x--)
                            buff[x+1]='0';
                }
           if(f>0)
              {
                     int n=f;
                     while(n)
                           {
                               int a=n%10;  
                               buff[i++]=(char)('0'+a);
                               count++;
                               n/=10;

                            }
                      int k=0;
                      buff[i]='.';
                      i++;
                      while(k<(count/2))
                          {   
                              char var;
                              var=buff[k];  
                              buff[k]=buff[count-k-1];
                              buff[count-k-1]=var;
                                k++;
                         }
                      n=f;
                      f=f-n;
                      int x=6;
                      while(x--)
                          {
                               int a=10*f;
                               buff[i++]=(char)('0'+a);
                               f=10*f;
                               n=f;
                               f=f-n;
                               
                           }
                 __asm__ __volatile__ ("syscall"::"a"(1), "D"(1), "S"(buff), "d"(i));
                 return(i);
              }
             else
              {
                    buff[0]='-';
                    i=1;
                    f=(-1)*f;
                    int n=f;
                     while(n)
                           {
                               int a=n%10;  
                               buff[i++]=(char)('0'+a);
                               count++;
                               n/=10;

                            }
                      count++; 	
                      int k=1;
                      buff[i]='.';
                      i++;
                      while(k<(count/2)+1)
                          {   
                              char var;
                              var=buff[k];  
                              buff[k]=buff[count-k];
                              buff[count-k]=var;
                                k++;
                         }
                      n=f;
                      f=f-n;
                      int x=6;
                      while(x--)
                          {
                               int a=10*f;
                               buff[i++]=(char)('0'+a);
                               f=10*f;
                               n=f;
                               f=f-n;
                               
                           }
                 __asm__ __volatile__ ("syscall"::"a"(1), "D"(1), "S"(buff), "d"(i));
                 return(i);

              }
     }

