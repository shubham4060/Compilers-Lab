#include <stdio.h>
#include "y.tab.h"
extern char* yytext;
int main()
{   int token;
    while(token=yylex())
        {
              switch(token)
             {
                 case AUTO : {printf("auto is a keyword\n");break;}
                 case ENUM : {printf("enum is a keyword\n");break;}
                 case RESTRICT : {printf("restrict is a keyword\n");break;}
                 case UNSIGNED : {printf("unsigned is a keyword\n");break;}
                 case BREAK : {printf("break is a keyword\n");break;}
                 case EXTERN : {printf("extern is a keyword\n");break;}
                 case RETURN : {printf("return is a keyword\n");break;}
                 case VOID : {printf("void is a keyword\n");break;}
                 case CASE : {printf("case is a keyword\n");break;}
                 case FLOAT : {printf("float is a keyword\n");break;}
                 case SHORT : {printf("short is a keyword\n");break;}
                 case VOLATILE : {printf("volatile is a keyword\n");break;}
                 case CHAR : {printf("char is a keyword\n");break;}
                 case FOR : {printf("for is a keyword\n");break;}
                 case SIGNED : {printf("signed is a keyword\n");break;}
                 case WHILE : {printf("while is a keyword\n");break;}
                 case CONST : {printf("const is a keyword\n");break;}
                 case GOTO : {printf("goto is a keyword\n");break;}
                 case SIZEOF : {printf("sizeof is a keyword\n");break;}
                 case _BOOL : {printf("_Bool is a keyword\n");break;}
                 case CONTINUE : {printf("continue is a keyword\n");break;}
                 case IF : {printf("if is a keyword\n");break;}
                 case STATIC : {printf("static is a keyword\n");break;}
                 case _COMPLEX : {printf("_Complex is a keyword\n");break;}
                 case DEFAULT : {printf("default is a keyword\n");break;}
                 case INLINE : {printf("inline is a keyword\n");break;}
                 case STRUCT : {printf("struct is a keyword\n");break;}
                 case _IMAGINARY : {printf("_Imaginary is a keyword\n");break;}
                 case DO : {printf("do is a keyword\n");break;}
                 case INT : {printf("int is a keyword\n");break;}
                 case SWITCH : {printf("switch is a keyword\n");break;}
                 case DOUBLE : {printf("double is a keyword\n");break;}
                 case LONG : {printf("long is a keyword\n");break;}
                 case TYPEDEF : {printf("typedef is a keyword\n");break;}
                 case ELSE : {printf("else is a keyword\n");break;}
                 case REGISTER : {printf("register is a keyword\n");break;}
                 case UNION : {printf("union is a keyword\n");break;}
                 case ADD : {printf("%s is for addition and a punctuator\n",yytext );break;}
                 case SUB : {printf("%s is for subtraction a punctuator\n", yytext);break;}
                 case MUL : {printf("%s is for multiplication a punctuator\n",yytext );break;}
                 case DIV : {printf("%s is for division a punctuator\n",yytext );break;}
                 case MOD : {printf("%s is for modulus a punctuator\n",yytext);break;}
                 case IDENTIFIER : {printf("%s is an identifier\n",yytext);break;}
                 case ICONSTANTS : {printf("%s is an integer constant\n",yytext );break;}
                 case FCONSTANTS : {printf("%s is a floating point constant\n",yytext );break;}
                 case SINGLE_LINE_COMMENT : {printf("%s is a single line comment\n",yytext );break;}
                 case MULTILINE_COMMENT : {printf("%s is a multiline comment\n",yytext );break;}
                 case PUNCTUATORS : {printf("%s is a punctuator\n",yytext );break;}
                 case PUNCTUATORS1 : {printf("%s is a punctuator\n",yytext );break;}
                 case ESCAPE_SEQ : {printf("%s is an escape sequence\n",yytext );break;}
                 case CHAR_CONSTANT :{printf("%s is a character constant\n",yytext );break;}
                 case STRING_CONSTANT : {printf("%s is a string constant\n",yytext );break;}
                 case ENUM_CONSTANT : {printf("%s is a enumeration constant",yytext);break;}
                 


             }
       }
return 0;
}
