#include<stdio.h>
int main()
{
    // 	TESTING SINGLE LINE COMMENTS
    /* testing
          multiple
           line
            comments        */ 
    //     TESTING ALL KEYWORDS

      
     auto  enum restrict unsigned
     break extern return void
     case   float short  volatile
     char   for    signed while
     const  goto    sizeof   _Bool
     continue   if   static   _Complex
     default   inline   struct     _Imaginary
     do         int   switch     double    long
     typedef    else    register union
     
       


    //       TESTING IDENTIFIERS,INTEGER CONSTANTS,FLOATING CONSTANTS AND ARITHMETIC OPERATIONS

    TEMP=2 + 4
    temp=3 + 4.7
    _dg1=4.7/3.4
    _ABC=3.5*6
    var909= 5%2
    _TEMP909=5.7 - 4.8  

     


    //       TESTING CHARACTER CONSTANTS,STRING CONSTANTS AND ESCAPE SEQUENCES
    
     'c'  'cd' 'cdsg sffsfs' \n  \t ' \  ""   "dfdfbd" "flex"



   //       TESTING ALL PUNCTUATORS

                     [ ]     ( )       { }       .        ->
                     ++       --        &        *         +
                      -       ~         !        /         %
                     <<       >>        <        >         <=
                     ==      !=         ^        |         &&
                     ||      ?          :        ;          ...
                     =       *=         /=      %=         +=
                    -=       <<=        >>=     &=         ^=
                     |=      ,          #  
    
  
     
}
