

int add(int a,int b)
{
     return a+b;

}


int main()
{
 int a;
 
 a=4+5;
 int b=3;                   
 a=4/3;

while(a<0)
    {
       d=s;
    }

for(i=0;i<n;i++)
    b=0;

do
  {
    a=1;
  }
while(a<0);

if(a<0)
    b=1;

if(a<0)
    b=1;
else
    b=2;

switch(a){

case 1: {a=1;}
case 2: {a=2;}
case 2: {a=3;}
case 4: {a=4;}
case 5: {a=5;}

default: {a=6;}

}

a=(b<0)?3:4;

a+=1;

a*=1;

a-=1;

a%=1;

a++;

a--;

a/=1;

a=a&b;

a=4*3;

a=4+3;

a=4%3;

a=9;

a=5.0;

char c;

c='a';

a=~a;

a=!a;

a=a|b;

a^=1;

a<<=1;

a>>=6;

a|=5;

return 0;

}
