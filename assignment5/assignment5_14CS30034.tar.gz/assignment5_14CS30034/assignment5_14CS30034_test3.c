int add (int a, int b) {
	 int c;
         c=a+b;
         return c;
}
void main () {
	int i, a[10], v = 5;
	double d;
	for (i=1; i<a[10]; i++) 
		i++;
	do i = i - 1; 
        while (a[i] < v);
	i = 2;
	if (i==v)
       i = 1;
	return;
}
