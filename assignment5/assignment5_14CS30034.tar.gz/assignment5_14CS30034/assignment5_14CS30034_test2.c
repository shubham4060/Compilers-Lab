int add(int a,int b)
  {
      int c;
      c=a+b;
      return c;
   }

int mul(int a,int b)
{
      int c;
      c=a*b;
      return c;
}

int div(int a,int b)
   {
      int c;
      c=a/b;
      return c;
   }
int sub(int a,int b)
  {
     int c;
     c=a-b;
     return c;
  }
void main()
 {
   int a=1;
   int b=2;
   int c=add(a,b);
   int d=mul(a,b);
   int e=div(b,a);
   int f=sub(b,a);
   return;
 }
