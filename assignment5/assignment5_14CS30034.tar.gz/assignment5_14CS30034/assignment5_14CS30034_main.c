#include <stdio.h>
#include "y.tab.h"
extern int yyparse();
int main() {
  int token;
  yyparse();
  return 0;
}
