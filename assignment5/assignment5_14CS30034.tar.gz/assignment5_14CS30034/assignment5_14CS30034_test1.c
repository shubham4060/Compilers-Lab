void main()
{
   int a=1,b=2,c=3;
   while(c--)
   {if(b==2)
    a=b*a;
   }
   return;
}
   
