#include "ass6_14CS30034_translator.h"

extern FILE *yyin;
extern vector <string> STRINGS;


int gblcount=0;						
std::map<int, int> labels;			
ofstream out;						
vector <quad> array;				
string sfilepath;				
string inputfile;				

void findlabels() { 
	for (vector<quad>::iterator it = array.begin(); it!=array.end(); it++) {
		int i;
		switch (it->op) {
			case LT:
			case GT:
			case LE:
			case GE:
			case EQOP:
			case NEOP:
			case GOTOOP:
			i = atoi(it->result.c_str());
			labels [i] = 1;
			break;
			default:
			break;
		}
	}
	int count = 0;
	for (std::map<int,int>::iterator it=labels.begin(); it!=labels.end(); ++it)
		it->second = count++;
}
inline bool isInteger(const std::string & s) {
	if(s.empty() || ((!isdigit(s[0])) && (s[0] != '-') && (s[0] != '+'))) return false ;
	char * p ;
	strtol(s.c_str(), &p, 10) ;
	return (*p == 0) ;
}
void computeActivationRecord(symtab* st) {
	int param = -20;
	int local = -24;
	for (list <sym>::iterator it = st->table.begin(); it!=st->table.end(); it++) {
		if (it->category =="param") {
			st->ar [it->name] = param;
			param +=it->size;			
		}
		else {
			if (it->name=="retVal") continue;
			else {
				st->ar [it->name] = local;
				local -=it->size;
			}
		}
	}

}
void genasm() {
	array = qarr.array;
	findlabels();
	list<symtab*> tablelist;
	for (list <sym>::iterator it = gTable->table.begin(); it!=gTable->table.end(); it++) {
		if (it->nest!=NULL) tablelist.push_back (it->nest);
	}
	for (list<symtab*>::iterator iterator = tablelist.begin(); 
		iterator != tablelist.end(); ++iterator) {
		computeActivationRecord(*iterator);
	}
	ofstream asmfile;
	asmfile.open (sfilepath.c_str());

	asmfile << "\t.file	\"test.c\"\n";
	for (list <sym>::iterator it = table->table.begin(); it!=table->table.end(); it++) {
		if (it->category!="function") {
			if (it->type->cat==_CHAR) { 
				if (it->init!="") {
					asmfile << "\t"<<".globl"<<"\t" << it->name << "\n";
					asmfile << "\t"<<".type"<<"\t" << it->name << ", @object\n";
					asmfile << "\t"<<".size"<<"\t" << it->name << ", 1\n";
					asmfile << it->name <<":\n";
					asmfile << "\t"<<".byte"<<"\t" << atoi( it->init.c_str()) << "\n";
				}
				else {
					asmfile << "\t"<<".comm"<<"\t" << it->name << ",1,1\n";
				}
			}
			if (it->type->cat==_INT) {
				if (it->init!="") {
					asmfile << "\t"<<".globl"<<"\t" << it->name << "\n";
					asmfile << "\t"<<".data\n";
					asmfile << "\t"<<".align 4\n";
					asmfile << "\t"<<".type"<<"\t" << it->name << ", @object\n";
					asmfile << "\t"<<".size"<<"\t" << it->name << ", 4\n";
					asmfile << it->name <<":\n";
					asmfile << "\t"<<".long"<<"\t" << it->init << "\n";
				}
				else {
					asmfile << "\t"<<".comm"<<"\t" << it->name << ",4,4\n";
				}
			}
		}
	}
	if (STRINGS.size()) {
		asmfile << "\t.section\t.rodata\n";
		for (vector<string>::iterator it = STRINGS.begin(); it!=STRINGS.end(); it++) {
			asmfile << ".LC" << it - STRINGS.begin() << ":\n";
			asmfile << "\t"<<".string"<<"\t" << *it << "\n";	
		}	
	}
	asmfile << "\t.text	\n";
	for (vector<quad>::iterator it = array.begin(); it!=array.end(); it++) {
		if (labels.count(it - array.begin())) {
			asmfile << ".L" << (2*gblcount+labels.at(it - array.begin()) + 2 )<< ": " << endl;
		}
		asmfile << &*it;
	
	}
	asmfile << 	"\t"<<".ident"<<"\t	\"Compiled by Shubham Sharma\"\n";
	asmfile << 	"\t"<<".section"<<"\t"<<".note.GNU-stack,\"\",@progbits\n";
	asmfile.close();
}
vector<string> params;
void ADD_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			if (isInteger(argument2))
				asm_out << "addl \t$" << atoi(argument2.c_str()) << ", " << table->ar[argument1] << "(%rbp)";
			else {
				asm_out << "movl \t" << table->ar[argument1] << "(%rbp), " << "%eax" << endl;
				asm_out << "\tmovl \t" << table->ar[argument2] << "(%rbp), " << "%edx" << endl;
				asm_out << "\taddl \t%edx, %eax\n";
				asm_out << "\tmovl \t%eax, " << table->ar[result] << "(%rbp)";
			}
}

void SUB_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "movl \t" << table->ar[argument1] << "(%rbp), " << "%eax" << endl;
			asm_out << "\tmovl \t" << table->ar[argument2] << "(%rbp), " << "%edx" << endl;
			asm_out << "\tsubl \t%edx, %eax\n";
			asm_out << "\tmovl \t%eax, " << table->ar[result] << "(%rbp)";
}

void MULT_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "movl \t" << table->ar[argument1] << "(%rbp), " << "%eax" << endl;
			if (isInteger(argument2))
				asm_out << "\timull \t$" << atoi(argument2.c_str()) << ", " << "%eax" << endl;
			else
				asm_out << "\timull \t" << table->ar[argument2] << "(%rbp), " << "%eax" << endl;
			asm_out << "\tmovl \t%eax, " << table->ar[result] << "(%rbp)";
}

void DIVIDE_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "movl \t" << table->ar[argument1] << "(%rbp), " << "%eax" << endl;
			asm_out << "\tcltd" << endl;
			asm_out << "\tidivl \t" << table->ar[argument2] << "(%rbp)" << endl;
			asm_out << "\tmovl \t%eax, " << table->ar[result] << "(%rbp)";
}

void MODOP_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << result << " = " << argument1 << " % " << argument2;			
}

void XOR_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << result << " = " << argument1 << " ^ " << argument2;		
}

void INOR_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << result << " = " << argument1 << " | " << argument2;	
}

void BAND_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << result << " = " << argument1 << " & " << argument2;	
}

void LEFTOP_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << result << " = " << argument1 << " << " << argument2;	
}

void RIGHTOP_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << result << " = " << argument1 << " >> " << argument2;	
}

void EQUAL_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			if(isInteger(argument1))
				asm_out << "movl\t$" << atoi(argument1.c_str()) << ", " << "%eax" << endl;
			else
				asm_out << "movl\t" << table->ar[argument1] << "(%rbp), " << "%eax" << endl;
			asm_out << "\tmovl \t%eax, " << table->ar[result] << "(%rbp)";
}

void EQUALSTR_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "movq \t$.LC" << argument1 << ", " << table->ar[result] << "(%rbp)";
}

void EQUALCHAR_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "movb\t$" << atoi(argument1.c_str()) << ", " << table->ar[result] << "(%rbp)";
}

void EQOP_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "movl\t" << table->ar[argument1] << "(%rbp), %eax\n";
			asm_out << "\tcmpl\t" << table->ar[argument2] << "(%rbp), %eax\n";
			asm_out << "\tje .L" << (2*gblcount+labels.at(atoi( result.c_str() )) +2 );
}

void NEOP_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "movl\t" << table->ar[argument1] << "(%rbp), %eax\n";
			asm_out << "\tcmpl\t" << table->ar[argument2] << "(%rbp), %eax\n";
			asm_out << "\tjne .L" << (2*gblcount+labels.at(atoi( result.c_str() )) +2 );
}

void LT_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "movl\t" << table->ar[argument1] << "(%rbp), %eax\n";
			asm_out << "\tcmpl\t" << table->ar[argument2] << "(%rbp), %eax\n";
			asm_out << "\tjl .L" << (2*gblcount+labels.at(atoi( result.c_str() )) +2 );
}

void GT_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "movl\t" << table->ar[argument1] << "(%rbp), %eax\n";
			asm_out << "\tcmpl\t" << table->ar[argument2] << "(%rbp), %eax\n";
			asm_out << "\tjg .L" << (2*gblcount+labels.at(atoi( result.c_str() )) +2 );
}

void LE_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "movl\t" << table->ar[argument1] << "(%rbp), %eax\n";
			asm_out << "\tcmpl\t" << table->ar[argument2] << "(%rbp), %eax\n";
			asm_out << "\tjle .L" << (2*gblcount+labels.at(atoi( result.c_str() )) +2 );
}

void GE_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "movl\t" << table->ar[argument1] << "(%rbp), %eax\n";
			asm_out << "\tcmpl\t" << table->ar[argument2] << "(%rbp), %eax\n";
			asm_out << "\tjge .L" << (2*gblcount+labels.at(atoi( result.c_str() )) +2 );
}

void GOTOOP_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "jmp .L" << (2*gblcount+labels.at(atoi( result.c_str() )) +2 );
}

void ADDRESS_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "leaq\t" << table->ar[argument1] << "(%rbp), %rax\n";
			asm_out << "\tmovq \t%rax, " <<  table->ar[result] << "(%rbp)";
}

void PTRR_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "movl\t" << table->ar[argument1] << "(%rbp), %eax\n";
			asm_out << "\tmovl\t(%eax),%eax\n";
			asm_out << "\tmovl \t%eax, " <<  table->ar[result] << "(%rbp)";
}

void PTRL_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "movl\t" << table->ar[result] << "(%rbp), %eax\n";
			asm_out << "\tmovl\t" << table->ar[argument1] << "(%rbp), %edx\n";
			asm_out << "\tmovl\t%edx, (%eax)";
}

void UMINUS_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "negq\t" << table->ar[argument1] << "(%rbp)";
}

void BNOT_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << result 	<< " = ~" << argument1;
}

void LNOT_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << result 	<< " = !" << argument1;	
}

void ARRR_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "movl\t" << table->ar[argument2] << "(%rbp), "<<"%eax" << endl;
			asm_out << "\tmovl\t" << table->ar[argument1] << "(%rbp,%rax,1), "<<"%eax" << endl;
			asm_out << "\tmovl \t%eax, " <<  table->ar[result] << "(%rbp)";
}

void ARRL_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "movl\t" << table->ar[argument1] << "(%rbp), "<<"%eax" << endl;
			asm_out << "\tmovl\t" << table->ar[argument2] << "(%rbp), "<<"%edx" << endl;
			asm_out << "\tmovl\t" << "%edx, " << table->ar[result] << "(%rbp,%rax,1)";
}

void _RETURN_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			if(result!="") asm_out << "movl\t" << table->ar[result] << "(%rbp), "<<"%eax";
			else asm_out << "nop";
}

void CALL_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			symtab* t = gTable->lookup (argument1)->nest;
			int i,j=0;	
			for (list <sym>::iterator it = t->table.begin(); it!=t->table.end(); it++) {
				i = distance ( t->table.begin(), it);
				if (it->category== "param") {
					switch(j){
                                           
						case 0: 
							asm_out << "movl \t" << table->ar[params[i]] << "(%rbp), " << "%eax" << endl;
                                        		asm_out << "\tmovq \t" << table->ar[params[i]] << "(%rbp), " << "%rdi" << endl;
							asm_out << "\tmovl \t%eax, " << (t->ar[it->name]-8 )<< "(%rsp)\n\t";
							j++;
							break;
						case 1:
							asm_out << "movl \t" << table->ar[params[i]] << "(%rbp), " << "%eax" << endl;
    			                                asm_out << "\tmovq \t" << table->ar[params[i]] << "(%rbp), " << "%rsi" << endl;
							asm_out << "\tmovl \t%eax, " << (t->ar[it->name]-8 )<< "(%rsp)\n\t";
							j++;
							break;
						case 2:
							asm_out << "movl \t" << table->ar[params[i]] << "(%rbp), " << "%eax" << endl;
                                    			asm_out << "\tmovq \t" << table->ar[params[i]] << "(%rbp), " << "%rdx" << endl;
							asm_out << "\tmovl \t%eax, " << (t->ar[it->name]-8 )<< "(%rsp)\n\t";
							j++;
							break;
						case 3:
							asm_out << "movl \t" << table->ar[params[i]] << "(%rbp), " << "%eax" << endl;
                                        		asm_out << "\tmovq \t" << table->ar[params[i]] << "(%rbp), " << "%rcx" << endl;
							asm_out << "\tmovl \t%eax, " << (t->ar[it->name]-8 )<< "(%rsp)\n\t";	
							j++;
							break;
						default:
							asm_out << "\tmovq \t" << table->ar[params[i]] << "(%rbp), " << "%rdi" << endl;	
							break;
				}
				}
				else break;
			}
			params.clear();
			asm_out << "call\t"<< argument1 << endl;
			asm_out << "\tmovl\t%eax, " << table->ar[result] << "(%rbp)";
}

void FUNC_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out <<".globl\t" << result << "\n";
			asm_out << "\t.type\t"	<< result << ", @function\n";
			asm_out << result << ": \n";
			asm_out << ".LFB" << gblcount <<":" << endl;
			asm_out << "\t.cfi_startproc" << endl;
			asm_out << "\tpushq \t%rbp" << endl;
			asm_out << "\t.cfi_def_cfa_offset 8" << endl;
			asm_out << "\t.cfi_offset 5, -8" << endl;
			asm_out << "\tmovq \t%rsp, %rbp" << endl;
			asm_out << "\t.cfi_def_cfa_register 5" << endl;
			table = gTable->lookup(result)->nest;
			asm_out << "\tsubq\t$" << table->table.back().offset << ", %rsp";
                        symtab *temp=table;
                        int i=0;
                        list<sym>::iterator it=temp->table.begin();
                        while(it!=temp->table.end())
                               {   if(it->category=="param")
                                            {
                                              if(i==0)
                                              {  asm_out<<"\n\tmovq\t%rdi, "<<table->ar[it->name]<<"(%rbp)";
                                                 i++;
                                             }
      					      else if(i==1)
                                             {
                                               asm_out<<"\n\tmovq\t%rsi, "<<table->ar[it->name]<<"(%rbp)";
					      i++;
                                              } 
                                             else if(i==2)
                                               {
						asm_out<<"\n\tmovq\t%rdx, "<<table->ar[it->name]<<"(%rbp)";
						i++;
                                                 }
				            else if(i==3)
						{
							asm_out<<"\n\tmovq\t%rcx, "<<table->ar[it->name]<<"(%rbp)";
							i++;
						}}
                                   else
                                             break;
                                   it++;
                                  }
}

void FUNCEND_ASM(ostream& asm_out,string argument1,string argument2,string result)
{
			asm_out << "leave\n";
			asm_out << "\t.cfi_restore 5\n";
			asm_out << "\t.cfi_def_cfa 4, 4\n";
			asm_out << "\tret\n";
			asm_out << "\t.cfi_endproc" << endl;
			asm_out << ".LFE" << gblcount++ <<":" << endl;
			asm_out << "\t.size\t"<< result << ", .-" << result;
}

ostream& operator<<(ostream& asm_out, const quad* q) {
	optype op = q->op;
	string result = q->result;
	string argument1 = q->arg1;
	string argument2 = q->arg2;
	if(op==PARAM){
		params.push_back(result);
		return asm_out;
	}
	asm_out << "\t";
        if(op==ADD)
                ADD_ASM(asm_out,argument1,argument2,result);
	else if(op==SUB)
		SUB_ASM(asm_out,argument1,argument2,result);
	else if(op==MULT)
		MULT_ASM(asm_out,argument1,argument2,result);
	else if(op==DIVIDE)
		DIVIDE_ASM(asm_out,argument1,argument2,result);
	else if(op==MODOP)
		MODOP_ASM(asm_out,argument1,argument2,result);
	else if(op==XOR)
		XOR_ASM(asm_out,argument1,argument2,result);
	else if(op==INOR)
		INOR_ASM(asm_out,argument1,argument2,result);
        else if(op==BAND)
		BAND_ASM(asm_out,argument1,argument2,result);
	else if(op==LEFTOP)
		LEFTOP_ASM(asm_out,argument1,argument2,result);
	else if(op==RIGHTOP)
		RIGHTOP_ASM(asm_out,argument1,argument2,result);
	else if(op==EQUAL)
		EQUAL_ASM(asm_out,argument1,argument2,result);
	else if(op==EQUALSTR)
		EQUALSTR_ASM(asm_out,argument1,argument2,result);
	else if(op==EQUALCHAR)
		EQUALCHAR_ASM(asm_out,argument1,argument2,result);
	else if(op==EQOP)
		EQOP_ASM(asm_out,argument1,argument2,result);
	else if(op==NEOP)
		NEOP_ASM(asm_out,argument1,argument2,result);
	else if(op==LT)
		LT_ASM(asm_out,argument1,argument2,result);
	else if(op==GT)
		GT_ASM(asm_out,argument1,argument2,result);
	else if(op==LE)
		LE_ASM(asm_out,argument1,argument2,result);
	else if(op==GE)
		GE_ASM(asm_out,argument1,argument2,result);
	else if(op==GOTOOP)
		GOTOOP_ASM(asm_out,argument1,argument2,result);
	else if(op==ADDRESS)
		ADDRESS_ASM(asm_out,argument1,argument2,result);
	else if(op==PTRR)
		PTRR_ASM(asm_out,argument1,argument2,result);
	else if(op==PTRL)
		PTRL_ASM(asm_out,argument1,argument2,result);
	else if(op==UMINUS)
		UMINUS_ASM(asm_out,argument1,argument2,result);
	else if(op==BNOT)	
		BNOT_ASM(asm_out,argument1,argument2,result);
	else if(op==LNOT)
		LNOT_ASM(asm_out,argument1,argument2,result);
	else if(op==ARRR)
		ARRR_ASM(asm_out,argument1,argument2,result);
        else if(op==ARRL)
		ARRL_ASM(asm_out,argument1,argument2,result);
	else if(op==_RETURN)
		_RETURN_ASM(asm_out,argument1,argument2,result);
	else if(op==CALL)
		CALL_ASM(asm_out,argument1,argument2,result);
	else if(op==FUNC)
		FUNC_ASM(asm_out,argument1,argument2,result);
	else if(op=FUNCEND)
		FUNCEND_ASM(asm_out,argument1,argument2,result);
        else
		asm_out << "op";
	asm_out << endl;
	return asm_out;
}
template<class T>
ostream& operator<<(ostream& asm_out, const vector<T>& v)
{
	copy(v.begin(), v.end(), ostream_iterator<T>(asm_out, " ")); 
	return asm_out;
}

int  main (int argc, char* argv[]) {
	gTable = new symtab("Global");
        string str(argv[1]);
        inputfile=str;
        sfilepath=str.substr(0,5)+"."+"s";
	table = gTable;
	yyin = fopen(inputfile.c_str(),"r"); 
	yyparse();
	table = gTable;
	table->computeOffsets();
	table->print(1);
	qarr.print();
	genasm();
};
