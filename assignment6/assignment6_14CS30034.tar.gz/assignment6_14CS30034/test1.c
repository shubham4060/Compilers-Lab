// iterative fibonacci

int prints(char *c);
int printi(int i);
int readi(int *eP);
int fib(int n)
{  
   int p=1;
   int pp=0;
   if(i==1)
        return 1;
   if(i==0)
        return 0;
   for(i=2;i<n;i++)
      {  
          int temp=p;
          p=p+pp;
          pp=temp;
      }
          
   return p;
}
int main() {
	int a=10,n;
        a=readi(&a);
        n=fib(a);
        printi(a);
        prints("th fibonacci number is ");
        printi(n);
        prints("\n");
        return 0;
}
