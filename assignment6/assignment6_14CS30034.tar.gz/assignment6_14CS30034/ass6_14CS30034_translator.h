
#include <bits/stdc++.h>
#include <iostream>
#include <vector>
#include <algorithm>
#define size_of_char 		1
#define size_of_int  		4
#define size_of_double		8
#define size_of_pointer		4

extern  char* yytext;
extern  int yyparse();

using namespace std;

class sym;				
class symtab;					
class quad;						
class quads;					
class symtype;				



enum type_e {	
_VOID, _CHAR, _INT, _DOUBLE, PTR, ARR}; 	
enum optype { EQUAL, EQUALSTR, EQUALCHAR, 
LT, GT, LE, GE, EQOP, NEOP,
GOTOOP, _RETURN,ADD, SUB, MULT, DIVIDE, RIGHTOP, LEFTOP, MODOP,
UMINUS, UPLUS, ADDRESS, RIGHT_POINTER, BNOT, LNOT,BAND, XOR, INOR,
PTRL, PTRR,ARRR, ARRL,PARAM, CALL, FUNC, FUNCEND
};


class symtype { 
public:
	symtype(type_e cat, symtype* ptr = NULL, int width = 1);
	type_e cat;
	int width;					
	symtype* ptr;				

	friend ostream& operator<<(ostream&, const symtype);
};

class sym { 
public:
	string name;				
	symtype *type;				
	string init;				
	string category;			
	int size;					
	int offset;			
	symtab* nest;				
	
	sym (string, type_e t=_INT, symtype* ptr = NULL, int width = 0);
	sym* update(symtype * t); 	
	sym* update(type_e t); 		
	sym* initialize (string);
	friend ostream& operator<<(ostream&, const sym*);
	sym* linkst(symtab* t);
};

class symtab {
public:
	string tname;			
	int tcount;			
	list <sym> table; 			
	symtab* parent;
	map<string, int> ar;	

	symtab (string name="");
	sym* lookup (string name);					
	void print(int all = 0);				
	void computeOffsets();					
};

class quad { 
public:
	optype op;					
	string result;			
	string arg1;			
	string arg2;				
	void print ();							
	void update (int addr);					
	quad (string result, string arg1, optype op = EQUAL, string arg2 = "");
	quad (string result, int arg1, optype op = EQUAL, string arg2 = "");
	friend ostream& operator<<(ostream&, const quad*);
};

class quads { 
public:
	vector <quad> array;		

	quads () {array.reserve(300);}
	void print ();								
	void printtab();						
};

class Singleton {	
public:
   static Singleton* GetInstance();
private:
   Singleton();
   static Singleton* pSingleton;				
};


sym* gentemp (type_e t=_INT, string init = "");		
sym* gentemp (symtype* t, string init = "");		

void backpatch (list <int>, int);
void emit(optype opL, string result, string arg1="", string arg2 = "");
void emit(optype op, string result, int arg1, string arg2 = "");

typedef list<int> lint;
list<int> makelist (int);							
list<int> merge (list<int> &, list <int> &);		

int sizeoftype (symtype*);							
string convert_to_string (const symtype*);			
string optostr(int);

sym* conv (sym*, type_e);							
bool typecheck(sym* &s1, sym* &s2);				
bool typecheck(symtype* s1, symtype* s2);		

int nextinstr();									
string NumberToString(int);						

void changeTable (symtab* newtable);
extern symtab* table;			
extern symtab* gTable;			
extern quads qarr;				
extern sym* currsym;			
struct expr {
	bool isbool;				
	sym* symp;					
	lint truelist;			
	lint falselist;			
	lint nextlist;
};

struct statement {
	lint nextlist;				
};

struct unary {
	type_e cat;
	sym* loc;				
	sym* symp;					
	symtype* type;			
};


template <typename T> string tostr(const T& t) { 
	ostringstream os; 
	os<<t; 
	return os.str(); 
} 

expr* convert2bool (expr*);				
expr* convertfrombool (expr*);			


