#include"myl.h"
#include<stdlib.h>
#include<stdio.h>
int main()
{
   
/*                          checking prints function to print character array                    */
int k=prints("checking printing string\nprints is working properly and total characters printed =");
int temp=printi(k);
k=prints("\n");

/*                          checking printing integer printi function                                               */
k=prints("checking printi function by printing 334 and -786 using printi function and also no. of characters printed\n");
temp=printi(334);
k=prints("\n");
k=prints("no. of characters printed are ");
temp=printi(temp);
k=prints("\n");
temp=printi(-786);
k=prints("\n");
k=prints("no. of characters printed are ");
temp=printi(temp);
k=prints("\n");

/*                          checking reading integer readi function                                */

k=prints("checking reading integer\nenter any value : ");
int *ep;
ep=(int *)malloc(sizeof(int));
int n;
n=readi(ep);
if(*ep==0)
   printf("input integer is %d\n ",n);
else
   printf("error in input\n");


/*                           checking reading float                                   */

printf("enter the float value\n");
fflush(stdout);
float *fp;
fp=(float *)malloc(sizeof(float));
n=readf(fp);
if(n==0)
     printf("input float value is %f\n",*fp);
else
     printf("error in float value");

 
/*                           checking printing float value                        */
printf("checking printing float values 567.3378 and -4765.545\n");
fflush(stdout);
float a,b;
a=567.3378;
b=-4765.545;
int q,w;
q=printd(a);
printf("\ncharacters printed = %d\n",q);
w=printd(b);
printf("\ncharacters printed = %d\n",w);
return 0;

}
