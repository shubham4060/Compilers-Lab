// quadratic equation predictor whether has real roots or imaginary

int prints(char *c);
int printi(int i);
int readi(int *eP);

void quad_solver(int a,int b)
{  
   int d=a*a;
   int k=4*b;
   d=d-k;
   if(d<0)
     { prints("Imaginary Roots\n");}
   else
      {
          prints("Real Roots\n");
     }
   return;
}

int main()
{
  prints("Enter quadratic equation constants a,b as in x^2+ax+b : ");
  int a,b;
  int k;
  a=readi(&k);
  b=readi(&k);
  quad_solver(a,b);
 return 0;
}
