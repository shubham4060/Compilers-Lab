int prints(char *c);
int printi(int i);
int readi(int *eP);

int add(int a,int b)
{
   if(a>b)
        {
               int c=a+b;
               return c;
        }
   else
       {

           int c=a+b;
           return c;
     }
}

int main()
{

   prints("enter first number :");
   int a,b;
   a=readi(&a);
  prints("enter second number :");
  b=readi(&b);
   b=add(a,b);
  prints("the result is : ");
  printi(b);
  prints("\n");
  return 0;
}
   
